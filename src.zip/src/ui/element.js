import Vue from 'vue'
import { Button, Form, Input, Select, FormItem,   } from "element-ui";
Vue.use(Button);
Vue.use(Form);
Vue.use(Input);
Vue.use(Select);
Vue.use(FormItem);



